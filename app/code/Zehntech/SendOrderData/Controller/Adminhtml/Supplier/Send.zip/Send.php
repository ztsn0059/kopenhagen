<?php


namespace Zehntech\SendOrderData\Controller\Adminhtml\Supplier;

use Magento\Framework\Controller\ResultFactory;

class Send extends \Magento\Backend\App\Action
{

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,   
        \Magento\Catalog\Model\ProductFactory $_productFactory,
        \Magento\Framework\Filesystem\Io\Sftp $sftp,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
    )
    {
        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->orderRepository = $orderRepository;
        $this->_productFactory = $_productFactory;
        $this->productCollectionFactory = $productCollectionFactory;
    }

    /**
     * Mapped Grid List page.
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $data = $this->getRequest()->getParam('source');
        $orderId = $this->getRequest()->getParam('order_id');
        $order = $this->orderRepository->get($orderId);
        echo "<pre>";

        $suppliers = array_unique(array_column($data, 'name'));
        //filter by source
        foreach ($suppliers as $key => $supplier) {
            
            $supplierId = $this->getOptionIdByLabel($supplier);
            
            $supplierItem = array_filter($data, function ($var) use ($supplier) {
                return ($var['name'] == $supplier);
            });
            // print_r($supplierItem);
            $collection = $this->getCollection($supplierId)->addAttributeToFilter('oem',array('in'=>array_column($supplierItem, 'oem')));
            
            $items = $order->getItems();
            foreach ($items as $key => $item) {
                $_product = $this->getProductByOem($collection,$item->getProduct()->getOem());
                if($_product){

                }
            }
            
        }

        echo "</pre>";
        die("hello");
        return "hello";
    }

    protected function getOptionIdByLabel($optionLabel)
    {
        $attributeCode = 'supplier';
        $_product = $this->_productFactory->create();
        $isAttributeExist = $_product->getResource()->getAttribute($attributeCode);
        $optionId = '';
        if ($isAttributeExist && $isAttributeExist->usesSource()) {
            $optionId = $isAttributeExist->getSource()->getOptionId($optionLabel);
        }
        return $optionId;
    }
    public function getCollection($supplierId)
    {
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect('*')
        ->addAttributeToFilter('supplier',$supplierId);
        return $collection;
    }

    protected function getProductByOem($collection,$oem)
    {
        foreach ($collection as $key => $product) {
            if($product->getOem()===$oem)
                return $product;
        }
    }


    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Zehntech_SendOrderData::send');
    }

}